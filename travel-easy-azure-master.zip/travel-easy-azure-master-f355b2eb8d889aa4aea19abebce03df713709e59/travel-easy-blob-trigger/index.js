const service = require('../services/services')
const constants = require('../constants/constants')
const helper = require('../utils/helpers')

module.exports = async function (context, myBlob) {

    context.log.info("blob Trigger : Start")
    context.log.info("Travel Easy blob trigger function processed blob \n Blob:", context.bindingData.blobTrigger, "\n Blob Size:", myBlob.length, "Bytes");

    let from = process.env.FROM_ADDRESS
    let status, attachments = [myBlob];
    let mailStatus = false

    let blobName = context.bindingData.blobTrigger
    blobName = blobName.split("/").pop()
    context.log.info("blobName", blobName)
    id = blobName.split(".")
    context.log.info("split Result",id)
    id = id[0]


    
    let visaDetails = await service.getApplicationStatus(id, context)
    let receiverMail = visaDetails.data.mail_id
    if(visaDetails.isSuccess){
      status = visaDetails.data.status
      mailStatus = await helper.mailer(
        from,
        receiverMail,
        process.env.EMAIL_SUBJECT,
        status,
        attachments,
        id,
        context)

      if(mailStatus){
        context.log.info("mail sent successfully")
      }
      else{
        context.log.error("mail cannot be sent for this id after invoking the helper :",id)
      }
    }else{
      context.log.error("mail cannot be sent for this id :",id)
    }
    context.log.info("Blob trigger : End")
};