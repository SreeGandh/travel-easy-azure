const mongoUtils = require('../utils/mongoUtils')
const visaModel = require('../models/visaApplication')
const passportModel = require('../models/passport')
const constants = require('../constants/constants');
const helper = require('../utils/helpers');
const SHA256 = require("crypto-js/sha256");
const azureUtils = require("../utils/azureUtils");
const dotenv = require("dotenv")
dotenv.config()

createVisaApplication = async(applicationDetails, context) => {
    // context.log.info("app det",applicationDetails)
    // let resp =await insertMany(passportModel, constants.PASSPORT)
    context.log.info("create Visa Application Service  Start... ")
    // context.log.info("insert many resp", resp)
    let response = {}
    try{
    
        date = applicationDetails.expected_date_of_travel.split('/')
        expectedDate = new Date(parseInt(date[2]),parseInt(date[1])-1,parseInt(date[0])+1)
        applicationDetails.expected_date_of_travel = expectedDate
    
         context.log.info("applicationDetails", applicationDetails)
         mostRecentApplication = await helper.mostRecentApplication(applicationDetails, context)
         context.log.info("most recent application", mostRecentApplication)
        // context.log.info(mostRecentApplication)
        //  context.log.info(mostRecentApplication.length)
        if(mostRecentApplication.length != 0){
            daysBetween  = helper.getDifferenceBetweenDays(Date.now(),mostRecentApplication[0].last_modified)
        }else{
            daysBetween = parseInt(process.env.VISA_REAPPLICATION_DURATION) + 1
        }
        // context.log.info(daysBetween)
        context.log.info("daysBetween", daysBetween)
        if (daysBetween <= constants.VISA_REAPPLICATION_DURATION){
            response = {
                isSuccess : false,
                code : constants.ERROR_CODES[7]
            }
        }else{
            // context.log.info(applicationDetails)
            result = await mongoUtils.insert(visaModel, applicationDetails)
            context.log.info("insert Result",result)
            if(result === null){
                throw new error("cannot insert document")
            }
            response = {
                isSuccess : true,
                code : constants.SUCCESS_CODES[1],
                data : result
            }
        }
    }
    catch(err){
        response = {
            isSuccess : false ,
            code : constants.ERROR_CODES[3]
        }
    }
    context.log.info("create Visa Application service End")
    return response
}

getApplicationStatus = async(id, context) => {
    context.log.info('get Application Status start')
    context.log.info("id" , id)
    let response = {}

    try{
        filterQuery = {application_id : id}
        // context.log.info(filterQuery)
        context.log.info("filterQuery", filterQuery)
        result = await mongoUtils.findOne(visaModel, filterQuery)

        context.log.info("get result", result)
        if(result === undefined){
            throw new error("no such id")
        }
        data = {
            id : result.application_id,
            status : result.status,
            destination : result.destination,
            visa_type : result.visa_type,
            mail_id : result.mail_id
        }

        if(data.status == constants.APPLICATION_STATUS_CODES[2]){
            data.file_url = result.file_url,
            data.upload_within =  new Date(result.last_modified.getTime() + (parseInt(process.env.FILE_UPLOAD_EXPIRATION_DURATION)*24*60*60*1000))

        }else if(data.status == constants.APPLICATION_STATUS_CODES[6]){
            data.active_till = result.active_till
        }

        context.log.info("final data", data)

        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[1],
            data : data
        }
         context.log.info(response)
         context.log.info('get Application Status end')

    }
    catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[2]
        }
    }
    return response
}

getApplicationsByStatus = async(statusCode, context) => {

    context.log.info('get Applications By Status start')

    context.log.info("status code", statusCode)

    response = {}
    try{
        findQuery = {status : constants.APPLICATION_STATUS_CODES[statusCode]}
        context.log.info("find Query", findQuery)

        if(findQuery.status === undefined){
            throw new error("wrong status code")
        }
        
        result = await mongoUtils.find(visaModel, findQuery)
        context.log.info("query result", result)
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[2],
            data : result
        }
    }catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[3]
        }
    }
    context.log.info('get Applications By Status end')
    return response
}

getApplicationDetails = async(id, context) => {

    context.log.info('get Application Details start')

    context.log.info("id" ,id)
    ////console.log("inside service id ", id)
    let response = {}
    try{
        filterQuery = {application_id : id}
        context.log.info("find Query", filterQuery)
        ////console.log("filter Query",filterQuery)
        result = await mongoUtils.findOne(visaModel, filterQuery)
        ////console.log("first find result", result)
        context.log.info("query result", result)
        if(result === undefined){
            ////console.log("inside first catch block")
            throw new error("no such id")
        }

        passportFilter = {id : result.passport_id}
        ////console.log("passportFilter", passportFilter)
        context.log.info("passport Filter",passportFilter)
        passportData = await mongoUtils.findOne(passportModel, passportFilter)
        ////console.log("passportData",passportData)
        context.log.info("passport Data",passportData)
        if(passportData === undefined){
            throw new error("no passport with such id")
        }

       
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[2],
            application_data : result,
            passport_data : passportData
        }

        context.log.info("response ", response)
       

    }catch(err){
        response = {
            isSuccess : false,
            code  : constants.ERROR_CODES[3]
        }
    }
    ////console.log("final response", response)
    context.log.info('get Application Details end')
    return response
}

modifyApplicationStatus = async(id, status, context) => {

    context.log.info('modify application details start')

    //console.log("inside service")
    try{
        //context.log.info(id , status)

        context.log.info("id", id)
        context.log.info("status", status)
        filterQuery = {
            application_id : id
        }
        //console.log("filter Query", filterQuery)
        context.log.info("find Query", filterQuery)

        result = await mongoUtils.findOne(visaModel, filterQuery)
        //console.log("filter Result", result)
        if(result == undefined){
            throw new error("no such id")
        }

        context.log.info("Query result", result)

        updateQuery = {
            $set :{
                status : constants.APPLICATION_STATUS_CODES[parseInt(status)],
                last_modified : new Date(Date.now())
            }
        }

        

        if(parseInt(status) === 2) {
            updateQuery = {
                $set :{
                    status : constants.APPLICATION_STATUS_CODES[parseInt(status)],
                    file_url : SHA256(result.application_id).toString(),
                    last_modified : new Date(Date.now())
                }
            }
        }else if(parseInt(status) === 6) {
            daysToBeAdded = constants.VISA_TYPES[result.visa_type]
            newDate = new Date(Date.now())
            date = new Date(newDate.getTime() + (parseInt(daysToBeAdded)*24*60*60*1000))
            updateQuery = {
                $set :{
                    status : constants.APPLICATION_STATUS_CODES[parseInt(status)],
                    active_till : date,
                    last_modified : new Date(Date.now())
                }
            }
        }

        context.log.info("update query", updateQuery)
        //console.log("update Query",updateQuery)
        updateResult = await mongoUtils.findOneAndUpdate(visaModel, filterQuery, updateQuery)
        context.log.info("update Result", updateResult)
        //console.log("updateResult",result)
        await azureUtils.writeQueue(process.env.VISA_QUEUE, id,context);
        response = {
            isSuccess : true,
            code : constants.SUCCESS_CODES[3],
            data : []
        }

    }catch(err){
        //console.log("inside service catch")
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[4]
        }
    }
    context.log.info('modify Application Status end')
    //console.log("final",response)
    return response
}

uploadDocument = async(fileUrl, bufferData, context) => {
    context.log.info('upload func service - start')
    let response = {}
    try{
        let fileName = bufferData[0].fileName
        let data = bufferData[0].data.toString()
        filterQuery = {
            file_url : fileUrl
        }

        let filterResult = await mongoUtils.findOne(visaModel, filterQuery)
        context.log.info('filter Result', filterResult)
        if(filterResult.status != constants.APPLICATION_STATUS_CODES[2]){

            response = {
                isSuccess : false,
                status : constants.ERROR_CODES[6],
                data : "sorry upload link expired "
            }
            return response

        }else{
            daysDifference = helper.getDifferenceBetweenDays(new Date(Date.now()), filterResult.last_modified)
            context.log.info('days difference', daysDifference)

            if(daysDifference > parseInt(process.env.FILE_UPLOAD_EXPIRATION_DURATION)){
                filterQuery = {
                    application_id : filterResult.application_id
                }

                updateQuery = {
                    $set :{
                        status : constants.APPLICATION_STATUS_CODES[5],
                        last_modified : new Date(Date.now())
                    }
                }
                updateResult = await mongoUtils.findOneAndUpdate(visaModel, filterQuery, updateQuery)
                context.log.info("update Result", updateResult)
                response = {
                    isSuccess : false,
                    code : constants.ERROR_CODES[6],
                    data : "sorry upload link expired "
                }
                context.log.info("response", response)
                return response
            }
        }

        let uploadStatus = await azureUtils.uploadToStorageAccount(filterResult.application_id, data,context)
        context.log.info("upload Status", uploadStatus)
        if(uploadStatus){

            filterQuery = {
                application_id : filterResult.application_id
            }

            updateQuery = {
                $set :{
                    status : constants.APPLICATION_STATUS_CODES[4],
                    last_modified : new Date(Date.now())
                }
            }
            updateResult = await mongoUtils.findOneAndUpdate(visaModel, filterQuery, updateQuery)

            response = {
                isSuccess : true,
                code : constants.SUCCESS_CODES[4],
                data : "documents uploaded successfully"
            }
        }
        else{
            response = {
                isSuccess : false,
                code : constants.ERROR_CODES[5],
                data : "document upload failure please try again"
            }
        }

    }catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[5],
            data : "document upload failure please try again"
        }
    }
    context.log.info("response", response)
    context.log.info('upload func service - end')
    return response
}

downloadDocument = async(fileUrl, context) => {
    context.log.info('services : download document - start')
    let response = {}
    try{
        filterQuery = {
            file_url : fileUrl
        }
        context.log.info("filter Query", filterQuery)
    
        let result = await mongoUtils.findOne(visaModel,filterQuery)
        
        context.log.info("Query Result", result)
        if(result === undefined){
            throw new error('no such id')
        }

        let application_id = result.application_id

        let buffer  = await azureUtils.downloadDocument(application_id, context)

        context.log.info("file buffer", buffer)

        response = {
            isSuccess : true,
            name : application_id+".pdf",
            buffer : buffer,
            code : constants.SUCCESS_CODES[5]
        }

    }catch(err){
        response = {
            isSuccess : false,
            data : "something went wrong",
            code : constants.ERROR_CODES[2]
        }
    }
    context.log.info("Response", response)
    context.log.info('services : download document - end')
    return response

}


module.exports = {
    createVisaApplication,
    getApplicationStatus,
    getApplicationDetails,
    getApplicationsByStatus,
    modifyApplicationStatus,
    uploadDocument,
    downloadDocument
}