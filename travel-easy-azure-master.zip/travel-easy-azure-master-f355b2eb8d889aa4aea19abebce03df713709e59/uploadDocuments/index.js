const multipart = require("parse-multipart")
const constants = require('../constants/constants')
const services = require('../services/services')

module.exports = async function (context, request) {
    context.log.info('uploadDocuments ... start')

    status_code = 200
    response = {}

    let fileUrl = context.bindingData.id
    let bodyBuffer = Buffer.from(request.body);
    let boundary = multipart.getBoundary(request.headers['content-type']);
    let parts = multipart.Parse(bodyBuffer, boundary);
    context.log.info("fileUrl" , fileUrl)
    context.log.info("file parts", parts)
    if (!(parts[0].data)) {
        status_code = 400
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[10],
            data : []
        }
     }else{
         response = await services.uploadDocument(fileUrl, parts, context)
     }
     context.log.info('upload Document .... end')
     context.res = {
        status : status_code,
        body : response
    }
    context.done();
    
};