
const passportModel = require('../models/passport')
const constants = require('../constants/constants')



insertMany = async(model, documentJsonArray) => {
    // context.log.info(documentJsonArray)
     let result = await model.insertMany(documentJsonArray)
     // .then(() => {
     //     context.log.info("data inserted")
     // }).catch(function(err) {
     //     context.log.info(err)
     // })
     return result
}

insert = async (model, document) => {
    let result = await new model(document).save()
    //context.log.info("insert", result)
    return result
}

findOne = async(model, filtervalue) => {
    let result = await model.findOne(filtervalue)
   // context.log.info("find one res", result)
    return result
}

find = async(model, filterQuery) => {
    let result = await model.find(filterQuery)
    //context.log.info("res", result)
    return result
}

findOneAndUpdate = async (model, filter_query, update_query) => {
    let result = await model.findOneAndUpdate(filter_query, update_query,{
        new : true
    })
    return result 
}

module.exports = {
    insertMany,
    insert,
    findOneAndUpdate,
    find,
    findOne
}