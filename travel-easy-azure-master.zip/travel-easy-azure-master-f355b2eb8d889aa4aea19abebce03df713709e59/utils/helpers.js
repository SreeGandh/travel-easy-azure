const visaModel = require('../models/visaApplication')
const nodemailer = require('nodemailer')
const constants = require('../constants/constants')


function getDifferenceBetweenDays(date1 , date2){
    let first_date = new Date(date1); 
    let sec_date = new Date(date2);
    // context.log.info(date1 , " + " ,date2)
    // context.log.info("first" , first_date)
    // context.log.info("seco" , sec_date)

    let diff_in_time = first_date.getTime() - sec_date.getTime()

    //context.log.info("time_dif" , diff_in_time)

    let diff_in_days = diff_in_time / (1000 * 3600 * 24)

    //context.log.info("diff_days", diff_in_days)

    return parseInt(diff_in_days)
}

mostRecentApplication = async (applicationDetails, context) => {
    context.log.info("Helper : Most Recent Application : Start")
    application = await visaModel.aggregate([
    {
        $match :{
            passport_id : applicationDetails.passport_id
        }
    },
    // {
    //     $sort : {
    //         last_modified : -1
    //     }
    // }
    {
        $limit : 1
    }
    ])
    context.log.info("applications : ",application)
    context.log.info("Helper : Most Recent Application :End")
    return application
}

mailer = async(fromId, toId, subject, text, attachments, applicationId, context) => {

    context.log.info("mail helper  : start")
    let sentStatus = false;
    try{
        let testAccount = await nodemailer.createTestAccount();
        let transporter = nodemailer.createTransport({
            host: "smtp.ethereal.email",
            port: 587,
            secure: false, // true for 465, false for other ports
            auth: {
              user: testAccount.user, // generated ethereal user
              pass: testAccount.pass, // generated ethereal password
            },
          });
    
          context.log.info("from Id", fromId)
          context.log.info("To Id", toId)
          context.log.info("subject", subject)
          context.log.info("text", text)
          context.log.info("attachments", attachments)
          let info = await transporter.sendMail({
            from : fromId,
            to : toId,
            subject : subject,
            text : text,
            attachments : [{
                filename : `${applicationId}.pdf`,
                content : new Buffer(attachments)
            }]
          });
    
          context.log.info("Message sent: %s", info.messageId);
          sentStatus = true
          
          context.log.info("Preview URL: %s", nodemailer.getTestMessageUrl(info));
    }catch(err){
        context.log.error("mail error", err)
        sentStatus = false
    }
    context.log.info("mail helper : end")
    return sentStatus
}



activeVisa = async(context) => {
    applications = await visaModel.aggregate([
        {
            $match :{
                status : constants.APPLICATION_STATUS_CODES[6]
            }
        }
    ])

    return applications
}


module.exports = {
    getDifferenceBetweenDays,
    mostRecentApplication,
    mailer,
    activeVisa
}