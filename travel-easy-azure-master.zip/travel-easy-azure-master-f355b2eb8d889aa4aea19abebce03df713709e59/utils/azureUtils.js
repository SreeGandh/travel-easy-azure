const { BlobServiceClient } = require('@azure/storage-blob');
const azure = require('azure-storage');
const mongoose = require('mongoose');
const { DefaultAzureCredential } = require("@azure/identity");
const { SecretClient } = require("@azure/keyvault-secrets");
const dotenv = require('dotenv')
// dotenv.config({path :'../.env'})
dotenv.config()


connectToDb = async() => {
    const connectionString = await connectToKeyVault("cosmosConnectionStringTravelEasy")
    context.log.info("connectionString",connectionString)
    mongoose.connect(connectionString, 
    {
  auth: {
    user: process.env.COSMODDB_USER,
    password: process.env.COSMOSDB_PASSWORD
  },
   useNewUrlParser: true , useUnifiedTopology: true, useFindAndModify: false,
   retryWrites: false}
   )
   .then(() => {
       context.log.info('Connection to CosmosDB successful')
       })
   .catch((err) => console.error(err));   
};

connectToKeyVault = async(secretName) => {

    const credential = new DefaultAzureCredential();

    const vaultName = "traveleasyvault";
    const url = `https://${vaultName}.vault.azure.net`;

    const client = new SecretClient(url, credential);

    // await putSecret(client);
    // const secretName = "conectionStringTravelEasy"

    return await getSecret(client, secretName)

}

// putSecret = async(client) => {
//   const secretName = "conectionStringTravelEasy"
//   const conectionString = "mongodb://traveleasy:pYtXbybwqvLLHn1O92lg1Dyo1HbLhtNGOkJruXkkojkVyC8kOej0i3gpe8wqWBoqKpULrwKV2NIOJfTVtRYLhg==@traveleasy.mongo.cosmos.azure.com:10255/?ssl=true&appName=@traveleasy@"
//   const result = await client.setSecret(secretName, conectionString);
//   context.log.info(result)
// }


getSecret = async(client, secretName) => {
  const secret = await client.getSecret(secretName)
  context.log.info(secret.value)
  return secret.value
}


/**
 * Helper to upload file to storage account
 * @param fileName : fileName
 * @param data : fileData
 * @param context : context to log info
 */
uploadToStorageAccount = async(fileName, data, context) => {
    context.log.info('upload file helper start')
    context.log.info('fileName',fileName)

    let containerName = "travel-easy-visa-doc-container"
    const azureConnectionString =  await connectToKeyVault("storageAccountKeyTravelEasy")
    context.log.info("storage connection String", azureConnectionString)
    const blobServiceClient = BlobServiceClient.fromConnectionString(azureConnectionString);
   // context.log.info("blobServiceClient", blobServiceClient)
    const containerClient = blobServiceClient.getContainerClient(containerName);

   // context.log.info("container creation", createContainerResponse)
    const blockBlobClient = containerClient.getBlockBlobClient(fileName+".pdf");
    const uploadBlobResponse = await blockBlobClient.upload(data, data.length);
    context.log.info("Blob was uploaded successfully. requestId: ", uploadBlobResponse.requestId);
    context.log.info('upload file helper end')

    if(uploadBlobResponse.requestId == undefined){
        return false
    }else{
        return true
    }
}

downloadDocument = async(blobName, context) => {
    
    context.log.info('azure util : download Document - start')
    let containerName = "travel-easy-visa-doc-container"
    try{
        const azureConnectionString =  await connectToKeyVault("storageAccountKeyTravelEasy")
        context.log.info("storage connection String", azureConnectionString)
        const blobServiceClient = BlobServiceClient.fromConnectionString(azureConnectionString);
        
        const containerClient = blobServiceClient.getContainerClient(containerName);
    
        fileBuffer = await containerClient.getBlockBlobClient(blobName + ".pdf").downloadToBuffer(0);
        context.log.info("filebuffer", fileBuffer)
        context.log.info("azure util : download Document - end")
        return fileBuffer
    }catch(err){
        context.log.error("azure util : Cannot find Buffer",err)
        return undefined
    }

}

writeQueue = async(queueName, message,context) => {
    context.log.info("Helper : write Queue : start")
    context.log.info("Queue Name", queueName)
    context.log.info("message", message)
    // let retryOperations = new azure.ExponentialRetryPolicyFilter();
    try {

        let storageAccount = "traveleasyazure"
        let StorageAccessKey = await connectToKeyVault("StorageAccountAccessKeyTravelEasy")
        context.log.info("Storage Account access key :", StorageAccessKey)

        let queueSvc = azure.createQueueService(storageAccount,StorageAccessKey)
        // .withFilter(retryOperations);
    
        let QueueMessageEncoder = azure.QueueMessageEncoder
        context.log.info("queue service created..")
    
        queueSvc.createQueueIfNotExists(queueName, function(error, results, response){
            if(!error){
                queueSvc.messageEncoder = new QueueMessageEncoder.TextBase64QueueMessageEncoder();
                queueSvc.createMessage(queueName, message ,function(error, results, response){
                    if(!error){
                      context.log.info("message cannot be inserted in queue", error)
                    }
                    else{
                        context.log.info("message inserted in queue", response)
                    }
                  })
            }
            else{
                context.log.info("error in creating queue",error)
            }
          });
    } catch (err) {
        context.log.error("QUEUE Error ", err)
    }
    context.log.info("Helper : writequeue : end")
}

(async() => {
    context.log.info("self calling func")
    await connectToDb().then(() => {
      context.log.info("function called and db connected")
    })
})();

module.exports = {
    uploadToStorageAccount,
    downloadDocument,
    writeQueue,
    connectToKeyVault
}