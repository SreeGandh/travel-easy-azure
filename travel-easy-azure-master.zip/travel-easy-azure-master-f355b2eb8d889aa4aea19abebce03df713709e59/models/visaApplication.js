const mongoose = require('mongoose')
const short = require('shortid')
const constants = require ('../constants/constants')

const visaApplicationSchema = mongoose.Schema({
    application_id : {
        type : String,
        default : short.generate,
        required : true
    },
    passport_id :{
        type : String,
        required : true
    },
    visa_type : {
        type : String,
        enum : [],
        required : true
    },
    destination : {
        type : String,
        required : true
    },
    expected_date_of_travel : {
        type : Date, 
        required : true
    },
    reason_of_travel : {
        type : String,
        required : true
    },
    status : {
        type : String,
        default : constants.APPLICATION_STATUS_CODES[1],
        required : true
    },
    last_modified :{
        type : Date,
        default : Date.now(),
        required : true
    },
    file_url : {
        type : String
    },
    active_till : {
        type : Date
    },
    mail_id :{
        type : String,
        required : true
    }
})

module.exports = mongoose.model('visa_application', visaApplicationSchema);