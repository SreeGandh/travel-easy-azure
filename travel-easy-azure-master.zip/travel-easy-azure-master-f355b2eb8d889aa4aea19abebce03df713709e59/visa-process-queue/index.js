const service = require('../services/services')
const constants = require('../constants/constants')
const helper = require('../utils/helpers')
const dotenv = require('dotenv')
dotenv.config()

module.exports = async function (context, myQueueItem) {
    context.log.info('Visa Process queue trigger function processed work item', myQueueItem);

    let from = process.env.FROM_ADDRESS
    let status, attachments = [];
    let mailStatus = false

    let visaDetails = await service.getApplicationStatus(myQueueItem, context)
    context.log.info('Queue gets Details of visa : ',visaDetails)
    if(visaDetails.isSuccess){
      let receiverMail = visaDetails.data.mail_id
      status = visaDetails.data.status
      mailStatus = await helper.mailer(
        from,
        receiverMail,
        process.env.EMAIL_SUBJECT,
        status,
        attachments,
        myQueueItem,
        context)

      if(mailStatus){
        context.log.info("mail sent successfully")
      }
      else{
        context.log.error("mail cannot be sent for this id :",myQueueItem)
      }
    }else{
      context.log.error("mail cannot be sent for this id :",myQueueItem)
    }
    context.log.info("Queue trigger : End")
};