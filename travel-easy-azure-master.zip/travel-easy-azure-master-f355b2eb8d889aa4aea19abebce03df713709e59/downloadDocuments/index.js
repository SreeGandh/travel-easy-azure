const constants = require('../constants/constants')
const services = require('../services/services')

module.exports = async function (context, req) {

    context.log.info("download Func : Start")
    status_code = 200
    response = {}

    let fileUrl = context.bindingData.id
    context.log.info("file Url : ",fileUrl)
    response = await services.downloadDocument(fileUrl, context)
    context.log.info("result from service : ", response)
    context.log.info("download Function : End")
    if(!response.isSuccess){
     status_code = 404  
     context.res = {
         status : status_code,
         body : response
     } 
    }else{
        context.res = {
            status : status_code,
            body :response.buffer,
            headers: {
                "Content-Disposition": `attachment; filename=${response.name}`
            }
        }
    }
};