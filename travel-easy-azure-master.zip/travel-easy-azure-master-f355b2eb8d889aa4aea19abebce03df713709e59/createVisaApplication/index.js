const constants = require('../constants/constants')
const services = require('../services/services')

module.exports = async function (context, req) {
    let statusCode = 200
    let response = {}
    credentials = req.body
    // context.log.info("credentials" , credentials)
    context.log.info("credentials", credentials)

    try {
        if(credentials.passport_id &&
           credentials.visa_type &&
           credentials.destination &&
           credentials.expected_date_of_travel &&
           credentials.reason_of_travel &&
           credentials.mail_id
           ){
            context.log.info("if case true ")
            response =  await services.createVisaApplication(credentials, context)
            context.log.info("final response",response)
           }
           else{
            throw new error("Details missing")
           }
    }
    catch(err){
        context.log.info("create visa application catch block executed...")
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[01],
        }
        statusCode = 412
    }

    context.res = {
        status : statusCode,
        body : response
    }

};