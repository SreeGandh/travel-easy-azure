const constants = require('../constants/constants')
const services = require('../services/services')

module.exports = async function (context, req) {

    let response = {}
    let statusCode = 200

    if(!req.query.status){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[8],
            error : "Details missing , try again !"
        }
        statusCode = 412
    }else {
        response = await services.getApplicationsByStatus(req.query.status, context)
    }

    context.res = {
        status : statusCode,
        body : response
    }
};