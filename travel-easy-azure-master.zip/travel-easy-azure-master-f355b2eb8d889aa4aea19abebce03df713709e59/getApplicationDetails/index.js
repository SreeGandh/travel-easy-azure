const constants = require('../constants/constants')
const services = require('../services/services')

module.exports = async function (context, req) {

    let response = {}
    let status_code = 200
    try{
        let id = context.bindingData.id
        if(!id){
            throw new error ("parameter missing")
        }
        // context.log.info(req.params.id)
        response = await services.getApplicationDetails(id, context)
        if(response.code === constants.ERROR_CODES[2]){
            status_code = 404
        }else if(response.isSuccess === false){
            status_code = 400
        }
    }
    catch(err){
        status_code = 400
    }

    context.res = {
        status : status_code,
        body : response
    }
};