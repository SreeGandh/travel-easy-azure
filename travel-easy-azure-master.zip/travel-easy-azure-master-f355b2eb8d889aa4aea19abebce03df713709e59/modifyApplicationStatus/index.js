const constants = require('../constants/constants')
const services = require('../services/services')

module.exports = async function (context, req) {

    let response = {}
    let status_code = 200
    credentials = req.body
    //console.log("req body", req)
    try {
        if(!(credentials.status)){
               throw new error("Details missing")
        }
        response = await services.modifyApplicationStatus(context.bindingData.id, req.body.status, context)
        if(response.code === constants.ERROR_CODES[2]){
            status_code = 404
        }else if(response.isSuccess === false){
            status_code = 400
        }
    }
    catch(err){
        response = {
            isSuccess : false,
            code : constants.ERROR_CODES[4]
        }
        status_code = 412
    }

    context.res = {
        status : status_code,
        body : response
    }
};