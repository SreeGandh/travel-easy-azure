const helper = require('../utils/helpers')
const services = require('../services/services')

module.exports = async function (context, myTimer) {
    context.log.info("visa expiry checker : start")
    var timeStamp = new Date().toISOString();
    
    if (myTimer.isPastDue)
    {
        context.log.info('JavaScript is running late!');
    }
    let activeApplications = await helper.activeVisa(context)

    activeApplications.forEach(async (element) => {
        let daysDifference = helper.getDifferenceBetweenDays(element.active_till, Date.now())
        if(daysDifference < 0){
            let updateResult = await services.modifyApplicationStatus(element.application_id, 8, context)
        }
    });
    context.log.info("visa expiry checker : end")
    context.log.info('JavaScript timer trigger function ran!', timeStamp);   
};